#!/bin/bash
echo "===================================="
echo "   MIGRANDO BASE DE DATOS SKINCARE"
echo "===================================="
echo
mysql -u root -p < skincare.sql
echo
echo "¡Base de datos migrada exitosamente!"