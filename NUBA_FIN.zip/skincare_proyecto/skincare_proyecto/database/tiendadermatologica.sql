-- phpMyAdmin SQL Dump
-- Base de datos: tiendadermatologica

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

-- Crear base de datos
CREATE DATABASE IF NOT EXISTS `tiendadermatologica` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `tiendadermatologica`;

-- --------------------------------------------------------
-- Estructura de tabla para la tabla `usuarios`
-- --------------------------------------------------------

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `contraseña` varchar(255) NOT NULL,
  `rol` enum('admin','empleado','cliente') NOT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Insertar usuarios de prueba
-- Contraseña para todos: "password123"
INSERT INTO `usuarios` (`nombre`, `email`, `contraseña`, `rol`) VALUES
('Administrador', 'admin@tienda.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin'),
('María López', 'empleado@tienda.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'empleado'),
('Juan Pérez', 'cliente1@test.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'cliente'),
('Ana García', 'cliente2@test.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'cliente');

-- --------------------------------------------------------
-- Estructura de tabla para la tabla `clientes`
-- --------------------------------------------------------

CREATE TABLE `clientes` (
  `id_cliente` int(11) NOT NULL,
  `tipo_piel` varchar(50) DEFAULT NULL,
  `alergias` text DEFAULT NULL,
  `sensibilidad` varchar(50) DEFAULT NULL,
  `historial_compras` text DEFAULT NULL,
  PRIMARY KEY (`id_cliente`),
  CONSTRAINT `clientes_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Insertar datos de clientes
INSERT INTO `clientes` (`id_cliente`, `tipo_piel`, `alergias`, `sensibilidad`) VALUES
(3, 'Mixta', 'Parabenos', 'Media'),
(4, 'Seca', 'Ninguna', 'Alta');

-- --------------------------------------------------------
-- Estructura de tabla para la tabla `productos`
-- --------------------------------------------------------

CREATE TABLE `productos` (
  `id_producto` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `precio` decimal(10,2) NOT NULL,
  `stock` int(11) NOT NULL,
  `categoria` varchar(100) DEFAULT NULL,
  `ingredientes` text DEFAULT NULL,
  PRIMARY KEY (`id_producto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Insertar productos
INSERT INTO `productos` (`nombre`, `descripcion`, `precio`, `stock`, `categoria`, `ingredientes`) VALUES
('Crema Hidratante Facial', 'Crema ligera para hidratación profunda', 45.00, 50, 'Facial', 'Ácido hialurónico, Vitamina E, Aloe vera'),
('Serum Vitamina C', 'Serum antioxidante con vitamina C pura', 65.00, 30, 'Facial', 'Vitamina C, Ácido ferúlico, Vitamina E'),
('Limpiador Facial Suave', 'Limpiador suave para todo tipo de piel', 28.00, 75, 'Limpieza', 'Agua micelar, Aloe vera, Extracto de pepino'),
('Protector Solar FPS 50+', 'Protección solar de amplio espectro', 38.50, 100, 'Protección', 'Óxido de zinc, Dióxido de titanio'),
('Contorno de Ojos', 'Reduce ojeras y líneas de expresión', 52.00, 40, 'Facial', 'Cafeína, Péptidos, Niacinamida'),
('Mascarilla Purificante', 'Mascarilla de arcilla para piel grasa', 35.00, 60, 'Tratamiento', 'Arcilla verde, Carbon activado, Tea tree'),
('Tónico Facial', 'Equilibra el pH de la piel', 32.00, 45, 'Limpieza', 'Agua de rosas, Hamamelis, Ácido salicílico'),
('Crema Noche Regeneradora', 'Regeneración celular nocturna', 58.00, 35, 'Facial', 'Retinol, Péptidos, Ácido hialurónico');

-- --------------------------------------------------------
-- Estructura de tabla para la tabla `inventario`
-- --------------------------------------------------------

CREATE TABLE `inventario` (
  `id_inventario` int(11) NOT NULL AUTO_INCREMENT,
  `id_producto` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `umbral_minimo` int(11) DEFAULT 5,
  `fecha_actualizacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_inventario`),
  KEY `id_producto` (`id_producto`),
  CONSTRAINT `inventario_ibfk_1` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id_producto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Insertar inventario
INSERT INTO `inventario` (`id_producto`, `cantidad`, `umbral_minimo`) VALUES
(1, 50, 10),
(2, 30, 5),
(3, 75, 15),
(4, 100, 20),
(5, 40, 8),
(6, 60, 10),
(7, 45, 10),
(8, 35, 7);

-- --------------------------------------------------------
-- Estructura de tabla para la tabla `tratamientos`
-- --------------------------------------------------------

CREATE TABLE `tratamientos` (
  `id_tratamiento` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `duracion` varchar(50) DEFAULT NULL,
  `costo` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id_tratamiento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Insertar tratamientos
INSERT INTO `tratamientos` (`nombre`, `descripcion`, `duracion`, `costo`) VALUES
('Limpieza Facial Profunda', 'Limpieza profunda con extracción de impurezas', '60 minutos', 80.00),
('Peeling Químico', 'Renovación celular con ácidos suaves', '45 minutos', 120.00),
('Hidratación Intensiva', 'Tratamiento hidratante con ácido hialurónico', '50 minutos', 95.00),
('Tratamiento Anti-Edad', 'Reducción de líneas de expresión y arrugas', '75 minutos', 150.00),
('Microdermoabrasión', 'Exfoliación mecánica para renovar la piel', '60 minutos', 110.00);

-- --------------------------------------------------------
-- Estructura de tabla para la tabla `citas`
-- --------------------------------------------------------

CREATE TABLE `citas` (
  `id_cita` int(11) NOT NULL AUTO_INCREMENT,
  `id_cliente` int(11) NOT NULL,
  `id_empleado` int(11) NOT NULL,
  `fecha_hora` datetime NOT NULL,
  `estado` enum('agendada','completada','cancelada') DEFAULT 'agendada',
  PRIMARY KEY (`id_cita`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_empleado` (`id_empleado`),
  CONSTRAINT `citas_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `citas_ibfk_2` FOREIGN KEY (`id_empleado`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Insertar citas de ejemplo
INSERT INTO `citas` (`id_cliente`, `id_empleado`, `fecha_hora`, `estado`) VALUES
(3, 2, '2025-11-20 10:00:00', 'agendada'),
(4, 2, '2025-11-20 14:30:00', 'agendada'),
(3, 2, '2025-11-15 09:00:00', 'completada');

-- --------------------------------------------------------
-- Estructura de tabla para la tabla `consultas`
-- --------------------------------------------------------

CREATE TABLE `consultas` (
  `id_consulta` int(11) NOT NULL AUTO_INCREMENT,
  `id_cliente` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `tipo_consulta` varchar(100) DEFAULT NULL,
  `notas` text DEFAULT NULL,
  PRIMARY KEY (`id_consulta`),
  KEY `id_cliente` (`id_cliente`),
  CONSTRAINT `consultas_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Estructura de tabla para la tabla `ventas`
-- --------------------------------------------------------

CREATE TABLE `ventas` (
  `id_venta` int(11) NOT NULL AUTO_INCREMENT,
  `id_cliente` int(11) NOT NULL,
  `id_empleado` int(11) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp(),
  `total` decimal(10,2) DEFAULT NULL,
  `metodo_pago` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_venta`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_empleado` (`id_empleado`),
  CONSTRAINT `ventas_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `ventas_ibfk_2` FOREIGN KEY (`id_empleado`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Estructura de tabla para la tabla `detalle_venta`
-- --------------------------------------------------------

CREATE TABLE `detalle_venta` (
  `id_venta` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio_unitario` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id_venta`,`id_producto`),
  KEY `id_producto` (`id_producto`),
  CONSTRAINT `detalle_venta_ibfk_1` FOREIGN KEY (`id_venta`) REFERENCES `ventas` (`id_venta`),
  CONSTRAINT `detalle_venta_ibfk_2` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id_producto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Estructura de tabla para la tabla `tratamiento_cliente`
-- --------------------------------------------------------

CREATE TABLE `tratamiento_cliente` (
  `id_cliente` int(11) NOT NULL,
  `id_tratamiento` int(11) NOT NULL,
  `fecha_inicio` date DEFAULT NULL,
  `estado` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_cliente`,`id_tratamiento`),
  KEY `id_tratamiento` (`id_tratamiento`),
  CONSTRAINT `tratamiento_cliente_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`),
  CONSTRAINT `tratamiento_cliente_ibfk_2` FOREIGN KEY (`id_tratamiento`) REFERENCES `tratamientos` (`id_tratamiento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Estructura de tabla para la tabla `historial_chat`
-- --------------------------------------------------------

CREATE TABLE `historial_chat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL,
  `mensaje_usuario` text DEFAULT NULL,
  `respuesta_bot` text DEFAULT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `historial_chat_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Estructura de tabla para la tabla `respuestas_bot`
-- --------------------------------------------------------

CREATE TABLE `respuestas_bot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pregunta_clave` varchar(255) NOT NULL,
  `respuesta` text NOT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Insertar respuestas del bot
INSERT INTO `respuestas_bot` (`pregunta_clave`, `respuesta`) VALUES
('horario', 'Nuestro horario de atención es de lunes a viernes de 9:00 AM a 6:00 PM, y sábados de 9:00 AM a 2:00 PM.'),
('productos', 'Contamos con una amplia gama de productos dermatológicos: cremas faciales, serums, protectores solares, limpiadores y tratamientos especializados.'),
('cita', 'Para agendar una cita puedes llamarnos o usar nuestro sistema de reservas en línea. ¿Te gustaría que te ayude a agendar?'),
('precio', 'Nuestros precios varían según el producto o tratamiento. ¿Te gustaría información sobre algo específico?'),
('ubicacion', 'Estamos ubicados en el centro de la ciudad. ¿Necesitas nuestra dirección exacta?');

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;