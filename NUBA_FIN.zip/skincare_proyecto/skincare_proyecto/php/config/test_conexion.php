<?php
require_once 'php/config/database.php';

echo "<h2>Prueba de Conexión a la Base de Datos</h2>";

// Probar conexión
if ($conn) {
    echo "✅ Conexión exitosa a la base de datos!<br><br>";
    
    // Probar consulta
    $sql = "SELECT COUNT(*) as total FROM usuarios";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    
    echo "Total de usuarios en la BD: <strong>" . $row['total'] . "</strong><br><br>";
    
    // Mostrar tablas
    $sql = "SHOW TABLES";
    $result = $conn->query($sql);
    
    echo "<h3>Tablas en la base de datos:</h3>";
    echo "<ul>";
    while ($row = $result->fetch_array()) {
        echo "<li>" . $row[0] . "</li>";
    }
    echo "</ul>";
    
} else {
    echo "❌ Error en la conexión";
}
?>
```

Luego abre en tu navegador:
```
http://localhost/skincare_proyecto/php/config/test_conexion.php