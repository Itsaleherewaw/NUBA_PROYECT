<?php session_start(); ?>
<!doctype html>
<html lang="es">
<head>
  <!-- ... mismo head que antes ... -->
</head>
<body>

  <div class="login-container">
    <div class="login-card">
      <!-- ... mismo contenido ... -->

      <!-- Cambiar form para usar PHP -->
      <form id="loginForm" action="../php/auth/login.php" method="POST">
        <div class="form-group">
          <label class="form-label" for="email">Correo Electrónico</label>
          <input 
            type="email" 
            class="form-control" 
            id="email" 
            name="email"
            placeholder="tu@email.com"
            required
          >
        </div>

        <div class="form-group">
          <label class="form-label" for="password">Contraseña</label>
          <div class="password-wrapper">
            <input 
              type="password" 
              class="form-control" 
              id="password" 
              name="password"
              placeholder="••••••••"
              required
            >
            <button type="button" class="toggle-password" onclick="togglePassword()">
              👁️
            </button>
          </div>
        </div>

        <button type="submit" class="btn-login">Iniciar Sesión</button>
      </form>

      <!-- ... resto del contenido ... -->
    </div>
  </div>

  <script>
  // Actualizar el JavaScript para manejar la respuesta PHP
  document.getElementById('loginForm').addEventListener('submit', async function(e) {
      e.preventDefault();
      
      const formData = new FormData(this);
      
      // Mostrar loading
      const btn = document.querySelector('.btn-login');
      const originalText = btn.textContent;
      btn.textContent = '🔐 Iniciando sesión...';
      btn.disabled = true;

      try {
          const response = await fetch(this.action, {
              method: 'POST',
              body: formData
          });
          
          const result = await response.json();
          
          if (result.success) {
              alert('¡Bienvenid@ a NUBA, ' + result.user.name + '! ✨');
              
              // Redirigir según el rol
              switch(result.user.role) {
                  case 'admin':
                      window.location.href = '../dashboards/admin.php';
                      break;
                  case 'empleado':
                      window.location.href = '../dashboards/empleado.php';
                      break;
                  default:
                      window.location.href = '../dashboards/cliente.php';
              }
          } else {
              alert('Error: ' + result.message);
              btn.textContent = originalText;
              btn.disabled = false;
          }
      } catch (error) {
          alert('Error de conexión');
          btn.textContent = originalText;
          btn.disabled = false;
      }
  });
  </script>
</body>
</html>