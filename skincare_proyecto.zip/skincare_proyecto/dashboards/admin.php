<?php
// dashboards/admin.php

session_start();

// 🔒 BLOQUE DE SEGURIDAD: Solo permite el rol 'admin'
if (!isset($_SESSION['user_rol']) || $_SESSION['user_rol'] !== 'admin') {
    // Redirige al login si no tiene el rol correcto
    header("Location: ../../login/login.html");
    exit();
}
// El resto del código HTML/PHP del dashboard de admin va aquí
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Administrador - NUBA Skincare</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-purple: #9b3876;
            --dark-purple: #6b1f52;
            --light-purple: #c54b8c;
            --bg-light: #faf5f8;
            --text-dark: #2d1b26;
            --success: #28a745;
            --danger: #dc3545;
            --warning: #ffc107;
            --info: #17a2b8;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg-light);
            color: var(--text-dark);
        }

        /* Navbar */
        .navbar {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            box-shadow: 0 2px 15px rgba(0,0,0,0.2);
            padding: 1rem 0;
            color: white;
        }

        .navbar-container {
            max-width: 1600px;
            margin: 0 auto;
            padding: 0 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-family: 'Playfair Display', serif;
            font-size: 2rem;
            font-weight: 700;
            color: white;
            letter-spacing: 0.15em;
        }

        .navbar-title {
            font-size: 0.85rem;
            opacity: 0.8;
            margin-top: 0.2rem;
            color: #ffd700;
        }

        .user-menu {
            display: flex;
            align-items: center;
            gap: 1.5rem;
        }

        .user-info {
            text-align: right;
        }

        .user-name {
            font-weight: 600;
            font-size: 1.1rem;
        }

        .user-role {
            font-size: 0.8rem;
            opacity: 0.8;
            color: #ffd700;
        }

        .btn-logout {
            background: rgba(255,255,255,0.15);
            color: white;
            padding: 0.7rem 1.8rem;
            border: 2px solid rgba(255,255,255,0.3);
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }

        .btn-logout:hover {
            background: white;
            color: #1a1a2e;
            border-color: white;
        }

        /* Dashboard Layout */
        .dashboard {
            max-width: 1600px;
            margin: 2rem auto;
            padding: 0 2rem;
            display: grid;
            grid-template-columns: 280px 1fr;
            gap: 2rem;
        }

        /* Sidebar */
        .sidebar {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            height: fit-content;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
        }

        .sidebar h3 {
            font-family: 'Playfair Display', serif;
            color: var(--primary-purple);
            margin-bottom: 1.5rem;
            font-size: 1.4rem;
        }

        .menu-item {
            padding: 1rem 1.2rem;
            margin-bottom: 0.5rem;
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 1rem;
            color: var(--text-dark);
            font-weight: 500;
            font-size: 0.95rem;
        }

        .menu-item:hover {
            background: var(--bg-light);
            color: var(--primary-purple);
            transform: translateX(5px);
        }

        .menu-item.active {
            background: linear-gradient(135deg, var(--primary-purple), var(--light-purple));
            color: white;
        }

        /* Main Content */
        .main-content {
            background: white;
            border-radius: 15px;
            padding: 2.5rem;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
        }

        .content-header {
            margin-bottom: 2.5rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .content-header h2 {
            font-family: 'Playfair Display', serif;
            color: var(--primary-purple);
            font-size: 2.2rem;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary-purple), var(--light-purple));
            color: white;
            padding: 1rem 2.5rem;
            border: none;
            border-radius: 10px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            font-size: 0.95rem;
        }

        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(155,56,118,0.4);
        }

        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
            margin-bottom: 3rem;
        }

        .stat-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 2rem;
            border-radius: 15px;
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);
            position: relative;
            overflow: hidden;
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1), transparent);
            animation: pulse 3s infinite;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); opacity: 0.5; }
            50% { transform: scale(1.1); opacity: 0.8; }
        }

        .stat-card:nth-child(2) {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        }

        .stat-card:nth-child(3) {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        }

        .stat-card:nth-child(4) {
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
        }

        .stat-icon {
            font-size: 3rem;
            margin-bottom: 1rem;
        }

        .stat-number {
            font-size: 2.8rem;
            font-weight: 700;
            font-family: 'Playfair Display', serif;
            margin-bottom: 0.5rem;
            position: relative;
            z-index: 1;
        }

        .stat-label {
            font-size: 1rem;
            opacity: 0.95;
            position: relative;
            z-index: 1;
        }

        .stat-change {
            margin-top: 0.8rem;
            font-size: 0.85rem;
            opacity: 0.9;
        }

        /* Charts */
        .charts-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 2rem;
            margin-bottom: 3rem;
        }

        .chart-card {
            background: var(--bg-light);
            padding: 2rem;
            border-radius: 15px;
            border: 2px solid #f0f0f0;
        }

        .chart-card h3 {
            color: var(--primary-purple);
            font-family: 'Playfair Display', serif;
            margin-bottom: 1.5rem;
            font-size: 1.5rem;
        }

        .chart-placeholder {
            background: white;
            height: 300px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #999;
            font-size: 1.1rem;
        }

        /* Table */
        .table-container {
            overflow-x: auto;
            margin-top: 2rem;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            background: var(--bg-light);
        }

        th {
            padding: 1.2rem;
            text-align: left;
            font-weight: 600;
            color: var(--text-dark);
            border-bottom: 3px solid var(--primary-purple);
        }

        td {
            padding: 1.2rem;
            border-bottom: 1px solid #f0f0f0;
        }

        tr:hover {
            background: var(--bg-light);
        }

        .status-badge {
            padding: 0.5rem 1.2rem;
            border-radius: 25px;
            font-size: 0.85rem;
            font-weight: 600;
            display: inline-block;
        }

        .status-active {
            background: #d1e7dd;
            color: #0f5132;
        }

        .status-inactive {
            background: #f8d7da;
            color: #842029;
        }

        .status-pending {
            background: #fff3cd;
            color: #856404;
        }

        .btn-action {
            background: var(--primary-purple);
            color: white;
            padding: 0.6rem 1.2rem;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 0.85rem;
            font-weight: 600;
            margin-right: 0.5rem;
            transition: all 0.3s;
        }

        .btn-action:hover {
            opacity: 0.8;
            transform: translateY(-2px);
        }

        .btn-danger {
            background: var(--danger);
        }

        .btn-success {
            background: var(--success);
        }

        .btn-warning {
            background: var(--warning);
            color: #000;
        }

        /* Forms */
        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 2rem;
        }

        .form-group {
            margin-bottom: 2rem;
        }

        .form-group.full-width {
            grid-column: 1 / -1;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.8rem;
            font-weight: 600;
            color: var(--text-dark);
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 1rem;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 0.95rem;
            transition: all 0.3s;
        }

        .form-group textarea {
            resize: vertical;
            min-height: 120px;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: var(--primary-purple);
            box-shadow: 0 0 0 3px rgba(155,56,118,0.1);
        }

        .hidden {
            display: none;
        }

        /* Quick Actions */
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            margin-bottom: 3rem;
        }

        .quick-action {
            background: white;
            border: 2px solid var(--primary-purple);
            padding: 1.5rem;
            border-radius: 12px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
        }

        .quick-action:hover {
            background: var(--primary-purple);
            color: white;
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(155,56,118,0.3);
        }

        .quick-action-icon {
            font-size: 2.5rem;
            margin-bottom: 0.8rem;
        }

        @media (max-width: 1200px) {
            .dashboard {
                grid-template-columns: 1fr;
            }

            .charts-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .form-grid {
                grid-template-columns: 1fr;
            }

            .content-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 1rem;
            }
        }
    </style>
</head>
<body>
    
    <nav class="navbar">
        <div class="navbar-container">
            <div>
                <div class="logo">NUBA</div>
                <div class="navbar-title">⭐ Panel de Administración</div>
            </div>
            <div class="user-menu">
                <div class="user-info">
                    <div class="user-name"><?php echo $_SESSION['user_nombre']; ?></div>
                    <div class="user-role"><?php echo ucfirst($_SESSION['user_rol']); ?></div>
                </div>
                <button class="btn-logout" onclick="logout()">Cerrar Sesión</button>
            </div>
        </div>
    </nav>

    <div class="dashboard">
        <aside class="sidebar">
            <h3>Panel Admin</h3>
            <div class="menu-item active" onclick="showSection('dashboard')">
                📊 Dashboard
            </div>
            <div class="menu-item" onclick="showSection('products')">
                🛍️ Productos
            </div>
            <div class="menu-item" onclick="showSection('orders')">
                📦 Pedidos
            </div>
            <div class="menu-item" onclick="showSection('users')">
                👥 Usuarios
            </div>
            <div class="menu-item" onclick="showSection('employees')">
                👔 Empleados
            </div>
            <div class="menu-item" onclick="showSection('reports')">
                📈 Reportes
            </div>
            <div class="menu-item" onclick="showSection('settings')">
                ⚙️ Configuración
            </div>
            <div class="menu-item" onclick="window.location.href='../index.html'">
                🏠 Ir a la Tienda
            </div>
        </aside>

        <main class="main-content">
            <section id="dashboard" class="content-section">
                <div class="content-header">
                    <h2>Dashboard General</h2>
                    <button class="btn-primary" onclick="alert('Generar reporte')">📊 Generar Reporte</button>
                </div>

                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-icon">💰</div>
                        <div class="stat-number">$45,280</div>
                        <div class="stat-label">Ventas del Mes</div>
                        <div class="stat-change">↗ +15% vs mes anterior</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon">📦</div>
                        <div class="stat-number">156</div>
                        <div class="stat-label">Pedidos Totales</div>
                        <div class="stat-change">↗ +8% esta semana</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon">👥</div>
                        <div class="stat-number">1,240</div>
                        <div class="stat-label">Clientes Registrados</div>
                        <div class="stat-change">↗ +42 nuevos hoy</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon">⭐</div>
                        <div class="stat-number">4.8</div>
                        <div class="stat-label">Rating Promedio</div>
                        <div class="stat-change">De 326 reseñas</div>
                    </div>
                </div>

                <div class="charts-grid">
                    <div class="chart-card">
                        <h3>Ventas de los Últimos 30 Días</h3>
                        <div class="chart-placeholder">📈 Gráfico de líneas (Integrar Chart.js)</div>
                    </div>
                    <div class="chart-card">
                        <h3>Top Categorías</h3>
                        <div class="chart-placeholder">🥧 Gráfico circular (Integrar Chart.js)</div>
                    </div>
                </div>

                <h3 style="margin: 2rem 0 1rem; color: var(--primary-purple); font-family: 'Playfair Display', serif; font-size: 1.8rem;">Actividad Reciente</h3>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Fecha/Hora</th>
                                <th>Actividad</th>
                                <th>Usuario</th>
                                <th>Detalles</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>07 Nov, 10:30</td>
                                <td>Nuevo pedido</td>
                                <td>María García</td>
                                <td>Pedido #1234 - $229.90</td>
                            </tr>
                            <tr>
                                <td>07 Nov, 09:15</td>
                                <td>Usuario registrado</td>
                                <td>Carlos Mendoza</td>
                                <td>Nuevo cliente</td>
                            </tr>
                            <tr>
                                <td>06 Nov, 18:45</td>
                                <td>Producto actualizado</td>
                                <td>Admin</td>
                                <td>Stock de Sérum Vital actualizado</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </section>

            <section id="products" class="content-section hidden">
                <div class="content-header">
                    <h2>Gestión de Productos</h2>
                    <button class="btn-primary" onclick="showAddProduct()">+ Nuevo Producto</button>
                </div>

                <div id="productList">
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Producto</th>
                                    <th>Categoría</th>
                                    <th>Precio</th>
                                    <th>Stock</th>
                                    <th>Estado</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>1</td>
                                    <td>Sérum Hidratante Vital</td>
                                    <td>Sérums</td>
                                    <td>$149.90</td>
                                    <td>45</td>
                                    <td><span class="status-badge status-active">Activo</span></td>
                                    <td>
                                        <button class="btn-action">✏️ Editar</button>
                                        <button class="btn-action btn-danger">🗑️ Eliminar</button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>2</td>
                                    <td>Limpiador Suave Daily</td>
                                    <td>Limpiadores</td>
                                    <td>$79.50</td>
                                    <td>12</td>
                                    <td><span class="status-badge status-pending">Stock Bajo</span></td>
                                    <td>
                                        <button class="btn-action">✏️ Editar</button>
                                        <button class="btn-action btn-danger">🗑️ Eliminar</button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>3</td>
                                    <td>Crema Nutritiva Night</td>
                                    <td>Cremas</td>
                                    <td>$119.00</td>
                                    <td>28</td>
                                    <td><span class="status-badge status-active">Activo</span></td>
                                    <td>
                                        <button class="btn-action">✏️ Editar</button>
                                        <button class="btn-action btn-danger">🗑️ Eliminar</button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div id="productForm" class="hidden" style="margin-top: 2rem;">
                    <h3 style="color: var(--primary-purple); margin-bottom: 1.5rem;">Agregar Nuevo Producto</h3>
                    <form class="form-grid">
                        <div class="form-group">
                            <label>Nombre del Producto</label>
                            <input type="text" placeholder="Ej: Sérum Hidratante">
                        </div>
                        <div class="form-group">
                            <label>Categoría</label>
                            <select>
                                <option>Sérums</option>
                                <option>Limpiadores</option>
                                <option>Cremas</option>
                                <option>Protectores</option>
                                <option>Aceites</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Precio</label>
                            <input type="number" placeholder="149.90">
                        </div>
                        <div class="form-group">
                            <label>Stock</label>
                            <input type="number" placeholder="50">
                        </div>
                        <div class="form-group full-width">
                            <label>Descripción</label>
                            <textarea placeholder="Descripción detallada del producto..."></textarea>
                        </div>
                        <div class="form-group full-width">
                            <button type="submit" class="btn-primary">Guardar Producto</button>
                            <button type="button" class="btn-action" onclick="hideAddProduct()" style="margin-left: 1rem;">Cancelar</button>
                        </div>
                    </form>
                </div>
            </section>

            <section id="orders" class="content-section hidden">
                <div class="content-header">
                    <h2>Gestión de Pedidos</h2>
                    <button class="btn-primary">📥 Exportar Todo</button>
                </div>

                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Pedido</th>
                                <th>Cliente</th>
                                <th>Fecha</th>
                                <th>Total</th>
                                <th>Estado</th>
                                <th>Empleado</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>#1234</td>
                                <td>María García</td>
                                <td>07 Nov 2025</td>
                                <td>$229.90</td>
                                <td><span class="status-badge status-pending">Pendiente</span></td>
                                <td>Carlos M.</td>
                                <td>
                                    <button class="btn-action">👁️ Ver</button>
                                    <button class="btn-action btn-danger">❌ Cancelar</button>
                                </td>
                            </tr>
                            <tr>
                                <td>#1233</td>
                                <td>Juan Pérez</td>
                                <td>06 Nov 2025</td>
                                <td>$149.90</td>
                                <td><span class="status-badge status-active">Completado</span></td>
                                <td>Ana R.</td>
                                <td>
                                    <button class="btn-action">👁️ Ver</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </section>

            <section id="users" class="content-section hidden">
                <div class="content-header">
                    <h2>Gestión de Clientes</h2>
                    <button class="btn-primary">📧 Enviar Boletín</button>
                </div>

                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>Email</th>
                                <th>Teléfono</th>
                                <th>Pedidos</th>
                                <th>Total Gastado</th>
                                <th>Estado</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td>María García</td>
                                <td>maria.garcia@ejemplo.com</td>
                                <td>+591 70514802</td>
                                <td>12</td>
                                <td>$1,248.00</td>
                                <td><span class="status-badge status-active">Activo</span></td>
                                <td>
                                    <button class="btn-action">👁️ Ver</button>
                                    <button class="btn-action btn-warning">✏️ Editar</button>
                                </td>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td>Juan Pérez</td>
                                <td>juan.perez@ejemplo.com</td>
                                <td>+591 71234567</td>
                                <td>8</td>
                                <td>$685.50</td>
                                <td><span class="status-badge status-active">Activo</span></td>
                                <td>
                                    <button class="btn-action">👁️ Ver</button>
                                    <button class="btn-action btn-warning">✏️ Editar</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </section>

            <section id="employees" class="content-section hidden">
                <div class="content-header">
                    <h2>Gestión de Empleados</h2>
                    <button class="btn-primary">+ Nuevo Empleado</button>
                </div>

                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>Email</th>
                                <th>Rol</th>
                                <th>Pedidos Procesados</th>
                                <th>Estado</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>E001</td>
                                <td>Carlos Mendoza</td>
                                <td>carlos.m@nuba.com</td>
                                <td>Empleado</td>
                                <td>156</td>
                                <td><span class="status-badge status-active">Activo</span></td>
                                <td>
                                    <button class="btn-action btn-warning">✏️ Editar</button>
                                    <button class="btn-action btn-danger">🗑️ Desactivar</button>
                                </td>
                            </tr>
                            <tr>
                                <td>E002</td>
                                <td>Ana Rodríguez</td>
                                <td>ana.r@nuba.com</td>
                                <td>Empleado</td>
                                <td>142</td>
                                <td><span class="status-badge status-active">Activo</span></td>
                                <td>
                                    <button class="btn-action btn-warning">✏️ Editar</button>
                                    <button class="btn-action btn-danger">🗑️ Desactivar</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </section>

            <section id="reports" class="content-section hidden">
                <div class="content-header">
                    <h2>Reportes y Análisis</h2>
                    <button class="btn-primary">📊 Generar Reporte</button>
                </div>
                <div class="chart-placeholder" style="height: 400px;">
                    📈 Área para gráficos y reportes avanzados
                </div>
            </section>

            <section id="settings" class="content-section hidden">
                <div class="content-header">
                    <h2>Configuración del Sistema</h2>
                    <button class="btn-primary">💾 Guardar Cambios</button>
                </div>
                <div class="form-grid">
                    <div class="form-group">
                        <label>Nombre de la Tienda</label>
                        <input type="text" value="NUBA Skincare">
                    </div>
                    <div class="form-group">
                        <label>Email de Contacto</label>
                        <input type="email" value="info@nuba.com">
                    </div>
                    <div class="form-group">
                        <label>Teléfono</label>
                        <input type="tel" value="+591 70514802">
                    </div>
                    <div class="form-group">
                        <label>Moneda</label>
                        <select>
                            <option>USD $</option>
                            <option>BS Bs.</option>
                            <option>EUR €</option>
                        </select>
                    </div>
                    <div class="form-group full-width">
                        <label>Descripción de la Tienda</label>
                        <textarea>NUBA - Skincare Boutique Natural. Productos orgánicos y naturales para el cuidado de la piel.</textarea>
                    </div>
                </div>
            </section>
        </main>
    </div>

    <script>
        function showSection(sectionName) {
            document.querySelectorAll('.content-section').forEach(section => {
                section.classList.add('hidden');
            });

            document.querySelectorAll('.menu-item').forEach(item => {
                item.classList.remove('active');
            });

            document.getElementById(sectionName).classList.remove('hidden');
            event.target.classList.add('active');
        }

        function showAddProduct() {
            document.getElementById('productList').classList.add('hidden');
            document.getElementById('productForm').classList.remove('hidden');
        }

        function hideAddProduct() {
            document.getElementById('productList').classList.remove('hidden');
            document.getElementById('productForm').classList.add('hidden');
        }

        function logout() {
            if(confirm('¿Estás seguro de cerrar sesión?')) {
                // Redirecciona al script de PHP que cierra la sesión
                window.location.href = '../php/auth/logout.php';
            }
        }
    </script>
</body>
</html>