<?php
// php/auth/login.php

session_start();
require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $database = new Database();
    $db = $database->getConnection();
    
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    
    // Buscar usuario
    $query = "SELECT * FROM usuarios WHERE email = ?";
    $stmt = $db->prepare($query);
    $stmt->execute([$email]);
    
    if ($stmt->rowCount() == 1) {
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // 🔑 CORRECCIÓN: Usamos $usuario['password']
        if (password_verify($password, $usuario['password'])) {
            // Login exitoso
            $_SESSION['user_id'] = $usuario['id'];
            $_SESSION['user_nombre'] = $usuario['nombre'];
            $_SESSION['user_email'] = $usuario['email'];
            $_SESSION['user_rol'] = $usuario['rol'];
            
            // Redirigir según el rol
            switch ($usuario['rol']) {
                // 🚀 CORRECCIÓN: Redirecciona a archivos .php
                case 'admin':
                    header("Location: ../../dashboards/admin.php");
                    break;
                case 'empleado':
                    header("Location: ../../dashboards/empleado.php");
                    break;
                case 'cliente':
                    header("Location: ../../dashboards/cliente.php");
                    break;
                default:
                    header("Location: ../../index.html"); 
            }
            exit;
        }
    }
    
    // Si el login falló
    header("Location: ../../login/login.html?error=" . urlencode("Email o contraseña incorrectos"));
    exit;
}
?>