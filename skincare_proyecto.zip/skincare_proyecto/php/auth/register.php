<?php
// php/auth/register.php

session_start();
require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $database = new Database();
    $db = $database->getConnection();
    
    // Asumimos que el formulario envía 'firstName'
    $nombre = trim($_POST['firstName']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirmPassword'];

    // ... (Validaciones) ...
    if ($password !== $confirm_password) {
        header("Location: ../../login/registro.html?error=" . urlencode("Las contraseñas no coinciden"));
        exit;
    }
    
    // Verificar si el email ya existe
    $query = "SELECT id FROM usuarios WHERE email = ?";
    $stmt = $db->prepare($query);
    $stmt->execute([$email]);
    
    if ($stmt->rowCount() > 0) {
        header("Location: ../../login/registro.html?error=" . urlencode("El email ya está registrado"));
        exit;
    }
    
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    // 🔑 CORRECCIÓN: Usamos la columna 'password' y las columnas de tu SQL
    $query = "INSERT INTO usuarios (nombre, email, password, rol) 
              VALUES (?, ?, ?, 'cliente')";
    $stmt = $db->prepare($query);
    
    if ($stmt->execute([$nombre, $email, $hashed_password])) {
        header("Location: ../../login/login.html?success=" . urlencode("Registro exitoso! Por favor, inicia sesión."));
        exit;
    } else {
        header("Location: ../../login/registro.html?error=" . urlencode("Error al registrar el usuario"));
        exit;
    }
}
?>