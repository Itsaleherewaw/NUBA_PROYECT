<?php
session_start();
// Asegurarse de que solo el admin pueda acceder a este script
if (!isset($_SESSION['user_rol']) || $_SESSION['user_rol'] !== 'admin') {
    header("Location: ../../login/login.html");
    exit();
}

require_once '../config/database.php';

// Definir la carpeta de destino para las imágenes
$target_dir = "../../img/productos/";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $database = new Database();
    $db = $database->getConnection();

    // 1. Recoger y limpiar los datos del formulario
    $nombre = trim($_POST['nombre']);
    $descripcion = trim($_POST['descripcion']);
    $precio = floatval($_POST['precio']);
    $stock = intval($_POST['stock']);
    $categoria = trim($_POST['categoria']);
    $imagen_file = $_FILES['imagen'];

    // 2. Validación de datos
    if (empty($nombre) || empty($descripcion) || $precio <= 0 || $stock < 0 || empty($categoria)) {
        header("Location: ../../dashboards/admin.php?section=products&error=" . urlencode("Todos los campos obligatorios deben ser llenados."));
        exit;
    }

    $imagen_nombre = ''; // Nombre de la imagen en la DB
    
    // 3. Gestión de la subida de la imagen
    if ($imagen_file && $imagen_file['error'] == UPLOAD_ERR_OK) {
        $file_extension = pathinfo($imagen_file['name'], PATHINFO_EXTENSION);
        // Crear un nombre único para evitar colisiones
        $imagen_nombre = uniqid('prod_') . '.' . $file_extension;
        $target_file = $target_dir . $imagen_nombre;

        // Verificar el tipo de archivo (solo permitir imágenes)
        $check = getimagesize($imagen_file["tmp_name"]);
        if($check === false) {
            header("Location: ../../dashboards/admin.php?section=products&error=" . urlencode("El archivo subido no es una imagen válida."));
            exit;
        }

        // Mover el archivo subido al directorio de destino
        if (!move_uploaded_file($imagen_file["tmp_name"], $target_file)) {
            header("Location: ../../dashboards/admin.php?section=products&error=" . urlencode("Error al subir la imagen."));
            exit;
        }
    } else {
        // Manejo si no se sube ninguna imagen (puedes usar una imagen placeholder si lo deseas)
        // Por ahora, si no hay imagen, $imagen_nombre queda vacío y el campo puede ser NULL en la DB.
    }

    // 4. Inserción en la base de datos
    try {
        $query = "INSERT INTO productos (nombre, descripcion, precio, stock, categoria, imagen) 
                  VALUES (:nombre, :descripcion, :precio, :stock, :categoria, :imagen)";
        
        $stmt = $db->prepare($query);

        $stmt->bindParam(':nombre', $nombre);
        $stmt->bindParam(':descripcion', $descripcion);
        $stmt->bindParam(':precio', $precio);
        $stmt->bindParam(':stock', $stock);
        $stmt->bindParam(':categoria', $categoria);
        $stmt->bindParam(':imagen', $imagen_nombre);

        if ($stmt->execute()) {
            // Éxito
            header("Location: ../../dashboards/admin.php?section=products&success=" . urlencode("Producto '{$nombre}' agregado exitosamente."));
            exit;
        } else {
            // Error de ejecución
            header("Location: ../../dashboards/admin.php?section=products&error=" . urlencode("Error al insertar el producto en la base de datos."));
            exit;
        }
    } catch (PDOException $e) {
        // Error de PDO (duplicado, etc.)
        header("Location: ../../dashboards/admin.php?section=products&error=" . urlencode("Error de DB: " . $e->getMessage()));
        exit;
    }

} else {
    // Si se accede directamente sin POST
    header("Location: ../../dashboards/admin.php");
    exit;
}
?>